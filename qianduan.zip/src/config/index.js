export default {
  Host: 'https://dapp.ys.dfym.cc',
  wssHost: 'dapp.ys.dfym.cc'
}
