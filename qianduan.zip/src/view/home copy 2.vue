<template>
    <header-nav :backIconType="2" title="我的委託訂單"></header-nav>
</template>

<script>
import headerNav from '@/components/header-nav.vue'

export default {
    name: 'home2',
    props: {
    },
    components: {
        headerNav
    },
    data() {
        return {
        }
    },
    mounted() {
    },
    methods: {
    }
}
</script>

<style>
</style>

