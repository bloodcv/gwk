<template>
    <div data-v-7932180b="">
        <div class="empty-state" data-v-b05b7c2c="" data-v-7932180b="">
            <img class="img-empty-state" src="../assets/static/image/img_nodata.f22e393b.bf2e71bc.png"
                data-v-b05b7c2c="">
            <div class="no-data" data-v-b05b7c2c="">{{$t('key1')}}</div>
        </div>
    </div>
</template>

<script>

export default {
    name: 'no-data',
    props: {
    },
    components: {
    },
    data() {
        return {
        }
    },
    mounted() {
    },
    methods: {
    }
}
</script>

<style>

.empty-state[data-v-b05b7c2c] {
    margin-top: .4rem;
    padding-bottom: .4rem;
    text-align: center;
    font-size: .4rem
}

.empty-state .img-empty-state[data-v-b05b7c2c] {
    margin-bottom: .56rem;
    width: 3.7rem;
    height: auto
}

.empty-state .no-data[data-v-b05b7c2c] {
    font-weight: 500;
    color: #aaa
}
</style>

